<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="Moving Platforms" tilewidth="48" tileheight="16" tilecount="2" columns="1">
 <image source="moveable_platforms.png" width="48" height="32"/>
</tileset>
