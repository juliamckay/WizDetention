<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="door" tilewidth="48" tileheight="48" tilecount="1" columns="1">
 <image source="door.png" width="48" height="48"/>
</tileset>
