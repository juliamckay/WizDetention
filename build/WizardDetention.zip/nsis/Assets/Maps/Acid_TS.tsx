<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="Acid" tilewidth="16" tileheight="16" tilecount="1" columns="1">
 <image source="Acid_01.png" width="16" height="16"/>
</tileset>
