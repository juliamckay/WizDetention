Music from Anttis:
https://www.soundclick.com/artist/default.cfm?bandid=1277008&content=songs
https://www.reddit.com/r/gameassets/comments/ewo5iu/i_have_released_my_2000_instrumental_pieces_free/