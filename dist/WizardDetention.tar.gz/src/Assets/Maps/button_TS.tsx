<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="button" tilewidth="28" tileheight="28" tilecount="1" columns="1">
 <image source="button.png" width="28" height="28"/>
</tileset>
