<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.9" tiledversion="1.9.0" name="Dungeon_Tiles" tilewidth="16" tileheight="16" tilecount="42" columns="7">
 <image source="Dungeon_Tiles_01.png" trans="aaffff" width="112" height="96"/>
</tileset>
